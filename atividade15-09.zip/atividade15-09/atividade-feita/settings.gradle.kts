pluginManagement {
    plugins {
        kotlin("jvm") version "2.4.10"
    }
}
rootProject.name = "patterns"